@if(!is_null($seo))
<meta name="description" content="{{$seo['meta_desc']}}">
@endif
@if(isset($_GET['page']) && $_GET['page'] >= 2)
<meta name="robots" content="noindex,nofollow" />
@else
<meta name="robots" content="index,follow"/>
@endif
<meta name="format-detection" content="telephone=no">
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@shopmajazi.com">
@if(!is_null($seo))
<meta name="twitter:title" content="{{$seo['meta_title']}}">
<meta name="twitter:description" content="{{$seo['meta_desc']}}">
@endif
<meta name="twitter:creator" content="@shopmajazi.com">
<meta name="twitter:card" content="summary_large_image">
@if(!is_null($seo))
    @if(!is_null($seo) && array_key_exists('image',$seo) && !is_null($seo['image']))
<meta name="twitter:image" content="{{URL::asset($seo['image'])}}">
    @elseif(isset($image) && !is_null($image))
<meta name="twitter:image" content="{{URL::asset($image)}}">
    @endif
<meta property="og:title" content="{{$seo['meta_title']}}">
@endif
<meta property="og:type" content="article">
<meta property="og:url" content="{{urldecode(URL::full())}}">
@if(!is_null($seo) && array_key_exists('image',$seo) && !is_null($seo['image']))
<meta property="og:image" content="{{URL::asset($seo['image'])}}">
@elseif(isset($image) && !is_null($image))
<meta property="og:image" content="{{URL::asset($image)}}">
@else
<meta property="og:image" content="{{secure_url('upload/logo.png')}}">
@endif
@if(!is_null($seo))
<meta property="og:description" content="{{$seo['meta_desc']}}">
<meta property="og:site_name" content="shopmajazi.com">
@endif
<link rel="canonical" href="{{urldecode(URL::full())}}"/>
@if(isset($faq) && !is_null($faq) && $faq != 'null')
        @include('site-v2.layout.faq-schema',['FAQ' => $faq])
@endif
@if(array_key_exists('seo',$seo) && !is_null($seo['seo']))
    {!! $seo['seo'] !!}
@endif
