<?php echo '<?xml version="1.0" encoding="UTF-8"?>'; ?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    @foreach($Posts as $post)
        <url>
            <loc>{{secure_url('blog/'.$post->slug)}}</loc>
            <lastmod>{{\Carbon\Carbon::parse($post->created_at)->format('Y-m-d')}}</lastmod>
        </url>
    @endforeach

</urlset>
