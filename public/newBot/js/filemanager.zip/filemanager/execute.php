<?php
$config = include 'config/config.php';
//TODO switch to array
extract($config, EXTR_OVERWRITE);

if(isset($_GET['ftp']) && $_GET['ftp'] == true) {
    session_name( 'FTPSESSID' );
}


function getLaravelUser($api_access=false){
    if(!$api_access){
        return false;
    }

    $config = include 'config/config.php';
    $mysqli = new mysqli($config['DB_HOST'], $config['DB_USERNAME'], $config['DB_PASSWORD'], $config['DB_DATABASE']);
    mysqli_set_charset($mysqli,"utf8");
    $userquery = $mysqli->query("SELECT * FROM `admins` WHERE `api_access` = '$api_access'");
    $user = $userquery->fetch_assoc();
    if(!$user){
        return false;
    }
    $user_id = $user['id'];
    $usermetasquery = $mysqli->query("SELECT * FROM `admin__metas` WHERE `admin_id` = '$user_id'");
    $usermetas=[];
    while($row = $usermetasquery->fetch_assoc()){
        $usermetas[$row['meta_key']] = $row['meta_value'];

    }
    $user['usermeta'] = $usermetas;
    return $user;

}

$api_access = $_GET['api_access'] ?? '';
if($api_access == 'parnafull'){
    $user = true;
}elseif($api_access){
    $user = getLaravelUser($api_access);
}else{
    $user = false;
}

if(!$user){
    die('دسترسی غیر مجاز کاربر');
}

if(isset($_GET['ftp']) && $_GET['ftp'] == true){
	$ftpaccess = true;
	if($user['ftp_access']){
		$config['ftp_host']         = $user['usermeta']['ftp_host'];
		$config['ftp_user']         = $user['usermeta']['ftp_username'];
		$config['ftp_pass']         = $user['usermeta']['ftp_password'];
		$config['ftp_base_folder']  = '/';
		$ftp_base_folder  = '/';
		//$config['ftp_base_url']     = 'http://www.parnamedia.com/parnamedia.com/test/';

		if(isset($user['usermeta']['ftp_fullaccess']) && $user['usermeta']['ftp_fullaccess'] > 0){
			$upload_dir  = '/';
//            $thumbs_base_path  = 'thumbs/';
//            $ftp_thumbs_dir = '/';
//            $config['ftp_base_url']     = 'http://dl.gallerygraph.ir/';

		}

	}else{
		die('دسترسی غیر مجاز اف تی پی');
	}
}else{
	$ftpaccess = false;
	if($user['usermeta']['userfolder']){
		$_SESSION['RF']["subfolder"] = $user['usermeta']['userfolder'];
	}else{
		$_SESSION['RF']["subfolder"] = '/';

	}
}



include 'include/utils.php';

if ($_SESSION['RF']["verify"] != "RESPONSIVEfilemanager")
{
	response(trans('forbiden').AddErrorLocation())->send();
	exit;
}

if (strpos($_POST['path'],'/')===0
	|| strpos($_POST['path'],'../')!==FALSE
	|| strpos($_POST['path'],'./')===0
	|| strpos($_POST['path'],'..\\')!==FALSE
	|| strpos($_POST['path'],'.\\')===0)
{
	response(trans('wrong path'.AddErrorLocation()))->send();
	exit;
}

if (isset($_SESSION['RF']['language']) && file_exists('lang/' . basename($_SESSION['RF']['language']) . '.php'))
{
	$languages = include 'lang/languages.php';
	if(array_key_exists($_SESSION['RF']['language'],$languages)){
		include 'lang/' . basename($_SESSION['RF']['language']) . '.php';
	}else{
		response(trans('Lang_Not_Found').AddErrorLocation())->send();
		exit;
	}
}
else
{
	response(trans('Lang_Not_Found').AddErrorLocation())->send();
	exit;
}

$ftp = ftp_con($config);

$base = $current_path;
$path = $base.$_POST['path'];
$cycle = TRUE;
$max_cycles = 50;
$i = 0;
while($cycle && $i<$max_cycles)
{
	$i++;
	if ($path == $base)  $cycle=FALSE;

	if (file_exists($path."config.php"))
	{
		require_once $path."config.php";
		$cycle = FALSE;
	}
	$path = fix_dirname($path)."/";
}

function returnPaths($_path,$_name,$config){
	global $ftp;
	$path = $config['current_path'].$_path;
	$path_thumb = $config['thumbs_base_path'].$_path;
	$name = null;
	if($ftp){
		$path = $config['ftp_base_folder'].$config['upload_dir'].$_path;
		$path_thumb = $config['ftp_base_folder'].$config['ftp_thumbs_dir'].$_path;
	}
	if ($_name)
	{
		$name = fix_filename($_name,$config);
		if (strpos($name,'../') !== FALSE || strpos($name,'..\\') !== FALSE)
		{
			response(trans('wrong name').AddErrorLocation())->send();
			exit;
		}
	}
	return array($path,$path_thumb,$name);
}

if(isset($_POST['paths'])){
	$paths = $paths_thumb = $names = array();
	foreach ($_POST['paths'] as $key => $path) {
		$name = null;
		if(isset($_POST['names'][$key])){
			$name = $_POST['names'][$key];
		}
		list($path,$path_thumb,$name) = returnPaths($path,$name,$config);
		$paths[] = $path;
		$paths_thumb[] = $path_thumb;
		$names = $name;
	}
}else{
	$name = null;
	if(isset($_POST['name'])){
		$name = $_POST['name'];
	}
	list($path,$path_thumb,$name) = returnPaths($_POST['path'],$name,$config);

}

$info = pathinfo($path);
if (isset($info['extension']) && !(isset($_GET['action']) && $_GET['action']=='delete_folder') &&
	(
		(!$config['ext_blacklist'] && !in_array(strtolower($info['extension']), $ext)) ||
		($config['ext_blacklist'] && in_array(fix_strtolower($file_array['extension']),$config['ext_blacklist']))
	)
	&& $_GET['action'] != 'create_file' )
{
	response(trans('wrong extension').AddErrorLocation())->send();
	exit;
}

if (isset($_GET['action']))
{
	switch($_GET['action'])
	{
		case 'delete_file':

			deleteFile($path,$path_thumb,$config);

			break;
		case 'delete_files':
			foreach ($paths as $key => $p) {
				deleteFile($p,$paths_thumb[$key],$config);
			}

			break;
		case 'delete_folder':
			if ($delete_folders){

				if($ftp){
					deleteDir($path,$ftp,$config);
					deleteDir($path_thumb,$ftp,$config);
				}else{
					if (is_dir($path_thumb))
					{
						deleteDir($path_thumb);
					}

					if (is_dir($path))
					{
						deleteDir($path);
						if ($fixed_image_creation)
						{
							foreach($fixed_path_from_filemanager as $k=>$paths){
								if ($paths!="" && $paths[strlen($paths)-1] != "/") $paths.="/";

								$base_dir=$paths.substr_replace($path, '', 0, strlen($current_path));
								if (is_dir($base_dir)) deleteDir($base_dir);
							}
						}
					}
				}
			}
			break;
		case 'create_folder':
			if ($create_folders)
			{

				$name = fix_filename($_POST['name'],$config);
				$path .= $name;
				$path_thumb .= $name;
				$res = create_folder(fix_path($path,$config),fix_path($path_thumb,$config),$ftp,$config);
				if(!$res){
					response(trans('Rename_existing_folder').AddErrorLocation())->send();
				}
			}
			break;
		case 'rename_folder':
			if ($rename_folders){
                if(!is_dir($path)) {
                    response(trans('wrong path'))->send();
                    exit;
                }
				$name=fix_filename($name,$config);
				$name=str_replace('.','',$name);

				if (!empty($name)){
					if (!rename_folder($path,$name,$ftp,$config))
					{
						response(trans('Rename_existing_folder').AddErrorLocation())->send();
						exit;
					}
					rename_folder($path_thumb,$name,$ftp,$config);
					if (!$ftp && $fixed_image_creation){
						foreach($fixed_path_from_filemanager as $k=>$paths){
							if ($paths!="" && $paths[strlen($paths)-1] != "/") $paths.="/";

							$base_dir=$paths.substr_replace($path, '', 0, strlen($current_path));
							rename_folder($base_dir,$name,$ftp,$config);
						}
					}
				} else {
					response(trans('Empty_name').AddErrorLocation())->send();
					exit;
				}
			}
			break;
		case 'create_file':
			if ($create_text_files === FALSE) {
				response(sprintf(trans('File_Open_Edit_Not_Allowed'), strtolower(trans('Edit'))).AddErrorLocation())->send();
				exit;
			}

			if (!isset($editable_text_file_exts) || !is_array($editable_text_file_exts)){
				$editable_text_file_exts = array();
			}

			// check if user supplied extension
			if (strpos($name, '.') === FALSE){
				response(trans('No_Extension').' '.sprintf(trans('Valid_Extensions'), implode(', ', $editable_text_file_exts)).AddErrorLocation())->send();
				exit;
			}

			// correct name
			$old_name = $name;
			$name=fix_filename($name,$config);
			if (empty($name))
			{
				response(trans('Empty_name').AddErrorLocation())->send();
				exit;
			}

			// check extension
			$parts = explode('.', $name);
			if (!in_array(end($parts), $editable_text_file_exts)) {
				response(trans('Error_extension').' '.sprintf(trans('Valid_Extensions'), implode(', ', $editable_text_file_exts)), 400)->send();
				exit;
			}

			$content = $_POST['new_content'];

			if($ftp){
				$temp = tempnam('/tmp','RF');
				file_put_contents($temp, $content);
				$ftp->put("/".$path.$name, $temp, FTP_BINARY);
				unlink($temp);
				response(trans('File_Save_OK'))->send();
			}else{
				if (!checkresultingsize(strlen($content))) {
					response(sprintf(trans('max_size_reached'),$MaxSizeTotal).AddErrorLocation())->send();
					exit;
				}
				// file already exists
				if (file_exists($path.$name)) {
					response(trans('Rename_existing_file').AddErrorLocation())->send();
					exit;
				}

				if (@file_put_contents($path.$name, $content) === FALSE) {
					response(trans('File_Save_Error').AddErrorLocation())->send();
					exit;
				} else {
					if (is_function_callable('chmod') !== FALSE){
						chmod($path.$name, 0644);
					}
					response(trans('File_Save_OK'))->send();
					exit;
				}
			}

			break;
		case 'rename_file':
			if ($rename_files){
				$name=fix_filename($name,$config);
				if (!empty($name))
				{
					if (!rename_file($path,$name,$ftp,$config))
					{
						response(trans('Rename_existing_file').AddErrorLocation())->send();
						exit;
					}

					rename_file($path_thumb,$name,$ftp,$config);

					if ($fixed_image_creation)
					{
						$info=pathinfo($path);

						foreach($fixed_path_from_filemanager as $k=>$paths)
						{
							if ($paths!="" && $paths[strlen($paths)-1] != "/") $paths.="/";

							$base_dir = $paths.substr_replace($info['dirname']."/", '', 0, strlen($current_path));
							if (file_exists($base_dir.$fixed_image_creation_name_to_prepend[$k].$info['filename'].$fixed_image_creation_to_append[$k].".".$info['extension']))
							{
								rename_file($base_dir.$fixed_image_creation_name_to_prepend[$k].$info['filename'].$fixed_image_creation_to_append[$k].".".$info['extension'],$fixed_image_creation_name_to_prepend[$k].$name.$fixed_image_creation_to_append[$k],$ftp,$config);
							}
						}
					}
				} else {
					response(trans('Empty_name').AddErrorLocation())->send();
					exit;
				}
			}
			break;
		case 'duplicate_file':
			if ($duplicate_files)
			{
				$name=fix_filename($name,$config);
				if (!empty($name))
				{
					if (!$ftp && !checkresultingsize(filesize($path))) {
						response(sprintf(trans('max_size_reached'),$MaxSizeTotal).AddErrorLocation())->send();
						exit;
					}
					if (!duplicate_file($path,$name,$ftp,$config))
					{
						response(trans('Rename_existing_file').AddErrorLocation())->send();
						exit;
					}

					duplicate_file($path_thumb,$name,$ftp,$config);

					if (!$ftp && $fixed_image_creation)
					{
						$info=pathinfo($path);
						foreach($fixed_path_from_filemanager as $k=>$paths)
						{
							if ($paths!="" && $paths[strlen($paths)-1] != "/") $paths.= "/";

							$base_dir=$paths.substr_replace($info['dirname']."/", '', 0, strlen($current_path));

							if (file_exists($base_dir.$fixed_image_creation_name_to_prepend[$k].$info['filename'].$fixed_image_creation_to_append[$k].".".$info['extension']))
							{
								duplicate_file($base_dir.$fixed_image_creation_name_to_prepend[$k].$info['filename'].$fixed_image_creation_to_append[$k].".".$info['extension'],$fixed_image_creation_name_to_prepend[$k].$name.$fixed_image_creation_to_append[$k]);
							}
						}
					}
				} else {
					response(trans('Empty_name').AddErrorLocation())->send();
					exit;
				}
			}
			break;

		case 'paste_clipboard':
			if ( ! isset($_SESSION['RF']['clipboard_action'], $_SESSION['RF']['clipboard']['path'])
				|| $_SESSION['RF']['clipboard_action'] == ''
				|| $_SESSION['RF']['clipboard']['path'] == '')
			{
				response()->send();
				exit;
			}

			$action = $_SESSION['RF']['clipboard_action'];
			$data = $_SESSION['RF']['clipboard'];


			if($ftp){
				if($_POST['path']!=""){
					$path.=DIRECTORY_SEPARATOR;
					$path_thumb.=DIRECTORY_SEPARATOR;
				}
				$path_thumb .= basename($data['path']);
				$path .= basename($data['path']) ;
				$data['path_thumb'] = DIRECTORY_SEPARATOR.$config['ftp_base_folder'].$config['ftp_thumbs_dir'].$data['path'];
				$data['path'] = DIRECTORY_SEPARATOR.$config['ftp_base_folder'].$config['upload_dir'].$data['path'];
			}else{
				$data['path_thumb'] = $thumbs_base_path.$data['path'];
				$data['path'] = $current_path.$data['path'];
			}

			$pinfo = pathinfo($data['path']);

			// user wants to paste to the same dir. nothing to do here...
			if ($pinfo['dirname'] == rtrim($path, DIRECTORY_SEPARATOR)) {
				response()->send();
				exit;
			}

			// user wants to paste folder to it's own sub folder.. baaaah.
			if (is_dir($data['path']) && strpos($path, $data['path']) !== FALSE){
				response()->send();
				exit;
			}

			// something terribly gone wrong
			if ($action != 'copy' && $action != 'cut'){
				response(trans('wrong action').AddErrorLocation())->send();
				exit;
			}
			if($ftp){
				if ($action == 'copy')
				{
					$tmp = time().basename($data['path']);
					$ftp->get($tmp, $data['path'], FTP_BINARY);
					$ftp->put(DIRECTORY_SEPARATOR.$path, $tmp, FTP_BINARY);
					unlink($tmp);

					if(url_exists($data['path_thumb'])){
						$tmp = time().basename($data['path_thumb']);
						@$ftp->get($tmp, $data['path_thumb'], FTP_BINARY);
						@$ftp->put(DIRECTORY_SEPARATOR.$path_thumb, $tmp, FTP_BINARY);
						unlink($tmp);
					}

				} elseif ($action == 'cut') {
					$ftp->rename($data['path'], DIRECTORY_SEPARATOR.$path);
					if(url_exists($data['path_thumb'])){
						@$ftp->rename($data['path_thumb'], DIRECTORY_SEPARATOR.$path_thumb);
					}
				}
			}else{
				// check for writability
				if (is_really_writable($path) === FALSE || is_really_writable($path_thumb) === FALSE){
					response(trans('Dir_No_Write').'<br/>'.str_replace('../','',$path).'<br/>'.str_replace('../','',$path_thumb).AddErrorLocation())->send();
					exit;
				}

				// check if server disables copy or rename
				if (is_function_callable(($action == 'copy' ? 'copy' : 'rename')) === FALSE){
					response(sprintf(trans('Function_Disabled'), ($action == 'copy' ? (trans('Copy')) : (trans('Cut')))).AddErrorLocation())->send();
					exit;
				}
				if ($action == 'copy')
				{
					list($sizeFolderToCopy,$fileNum,$foldersCount) = folder_info($path,false);
					if (!checkresultingsize($sizeFolderToCopy)) {
						response(sprintf(trans('max_size_reached'),$MaxSizeTotal).AddErrorLocation())->send();
						exit;
					}
					rcopy($data['path'], $path);
					rcopy($data['path_thumb'], $path_thumb);
				} elseif ($action == 'cut') {
					rrename($data['path'], $path);
					rrename($data['path_thumb'], $path_thumb);

					// cleanup
					if (is_dir($data['path']) === TRUE){
						rrename_after_cleaner($data['path']);
						rrename_after_cleaner($data['path_thumb']);
					}
				}
			}

			// cleanup
			$_SESSION['RF']['clipboard']['path'] = NULL;
			$_SESSION['RF']['clipboard_action'] = NULL;

			break;
		case 'chmod':
			$mode = $_POST['new_mode'];
			$rec_option = $_POST['is_recursive'];
			$valid_options = array('none', 'files', 'folders', 'both');
			$chmod_perm = ($_POST['folder'] ? $chmod_dirs : $chmod_files);

			// check perm
			if ($chmod_perm === FALSE) {
				response(sprintf(trans('File_Permission_Not_Allowed'), (is_dir($path) ? (trans('Folders')) : (trans('Files')) )).AddErrorLocation())->send();
				exit;
			}
			// check mode
			if (!preg_match("/^[0-7]{3}$/", $mode)){
				response(trans('File_Permission_Wrong_Mode').AddErrorLocation())->send();
				exit;
			}
			// check recursive option
			if (!in_array($rec_option, $valid_options)){
				response(trans("wrong option").AddErrorLocation())->send();
				exit;
			}
			// check if server disabled chmod
			if (!$ftp && is_function_callable('chmod') === FALSE){
				response(sprintf(trans('Function_Disabled'), 'chmod').AddErrorLocation())->send();
				exit;
			}

			$mode = "0".$mode;
			$mode = octdec($mode);
			if($ftp){
				$ftp->chmod($mode, "/".$path);
			}else{
				rchmod($path, $mode, $rec_option);
			}

			break;
		case 'save_text_file':
			$content = $_POST['new_content'];
			// $content = htmlspecialchars($content); not needed
			// $content = stripslashes($content);

			if($ftp){
				$tmp = time();
				file_put_contents($tmp, $content);
				try{
					$ftp->put("/".$path, $tmp, FTP_BINARY);
				}catch(FtpClient\FtpException $e){
					echo $e->getMessage();
				}
				unlink($tmp);
				response(trans('File_Save_OK'))->send();
			}else{
				// no file
				if (!file_exists($path)) {
					response(trans('File_Not_Found').AddErrorLocation())->send();
					exit;
				}

				// not writable or edit not allowed
				if (!is_writable($path) || $edit_text_files === FALSE) {
					response(sprintf(trans('File_Open_Edit_Not_Allowed'), strtolower(trans('Edit'))).AddErrorLocation())->send();
					exit;
				}

				if (!checkresultingsize(strlen($content))) {
					response(sprintf(trans('max_size_reached'),$MaxSizeTotal).AddErrorLocation())->send();
					exit;
				}
				if (@file_put_contents($path, $content) === FALSE) {
					response(trans('File_Save_Error').AddErrorLocation())->send();
					exit;
				} else {
					response(trans('File_Save_OK'))->send();
					exit;
				}
			}

			break;
		default:
			response(trans('wrong action').AddErrorLocation())->send();
			exit;
	}
}
?>
