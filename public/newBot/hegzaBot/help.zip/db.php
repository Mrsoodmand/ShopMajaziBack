<?php
$servername = "localhost";
$username = "shomarem_shomare";
$password = "Mahdi_930";
$DB = "Mahdi_930";
$mysqli = new mysqli($servername, $username, $password, $username);
mysqli_set_charset($mysqli, "utf8");
$req = json_encode($request);
$mysqli->query("INSERT INTO `hegza_bot`(`data`) VALUES ('$req')");

